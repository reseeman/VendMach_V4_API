﻿using System.Windows.Controls;

namespace VendMach.Scripts
{
    class FrameApp
    {
        public static Frame frmObj;
    }
}
